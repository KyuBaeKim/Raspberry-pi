import socket
from threading import Thread

HOST = '192.168.219.103'
PORT = 9999        

def threaded(client_socket, addr):
  print('Connected by', addr)
  while True:
    # 메시지 수신 대기 
    data = client_socket.recv(1024)
    if not data:
        break
    print('Received from', addr, data.decode())
    client_socket.sendall(data)

  client_socket.close()

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.settimeout(0.3)
server_socket.bind((HOST, PORT))
server_socket.listen()

# accept 함수에서 대기, 클라이언트 접속 시 새로운 소켓을 리턴
while True:
  try:
    client_socket, addr = server_socket.accept()
  except socket.timeout:
    continue
  
  # 새로운 스레드로 threaded 실행
  t = Thread(target=threaded, args=(client_socket, addr))
  t.start()

server_socket.close()
