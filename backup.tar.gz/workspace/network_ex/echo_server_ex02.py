import net
   
def echo(client_socket, addr): 
  print('Connected by', addr)
  while True:
    # 메시지 수신 대기 
    data = client_socket.recv(1024)
    if not data:
        break
    print('Received from', addr, data.decode())
    client_socket.sendall(data)

  client_socket.close()

ADDR = ('192.168.219.103', 9999)
net.run_server(ADDR, echo)
