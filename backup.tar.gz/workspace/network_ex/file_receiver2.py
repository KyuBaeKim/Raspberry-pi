from net import run_server, receive_file

ADDR = ("127.0.0.1", 6000)
run_server(ADDR, receive_file)