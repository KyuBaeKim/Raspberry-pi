from net import send_file

DEST = ("127.0.0.1", 6000)
FILE_PATH = "c:/temp/ESP_8266_BIN0.92.bin"

send_file(DEST, FILE_PATH)