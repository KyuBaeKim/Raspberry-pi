from net import send_file

DEST = ("127.0.0.1", 6000)

files = [
  'c:/temp/ESP_8266_BIN0.92.bin',
  'c:/temp/ESP8266_AT_V00180902_02_baudrate+watchdog+added.zip',
  'c:/temp/ESP8266_AT25-SDK112-512k.bin'
]

# 방법1
for file in files:
  send_file(DEST, file)

print('=================================')

from threading import Thread
# 방법2 - 스레드 이용  
for file in files:
  t = Thread(target=send_file, args=(DEST, file))
  t.start()