import socket 
from threading import Thread
import os

def run_server(addr, thread_fn):
  server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
  server_socket.settimeout(0.3)
  server_socket.bind(addr)
  server_socket.listen()

  # accept 함수에서 대기, 클라이언트 접속 시 새로운 소켓을 리턴
  while True:
    try:
      client_socket, addr = server_socket.accept()
    except socket.timeout:
      continue
    
    # 새로운 스레드로 threaded 실행
    t = Thread(target=thread_fn, args=(client_socket, addr))
    t.start()

  server_socket.close()


def file_read(file_path): 
  with open(file_path, 'rb') as f:
    while True :
      data = f.read(1024)
      if not data :
        break
      yield data

def send_file(addr, file_path):
  with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    try :
      s.connect(addr)
      fileSize = os.path.getsize(file_path)
      file_name = file_path.split('/')[-1]
      s.sendall(f'{file_name}/{fileSize}'.encode())

      isready = s.recv(1024).decode()
      if isready == "ready":
          for data in file_read(file_path):
              s.sendall(data)

          print(file_name, "/", fileSize)
          print("전송완료")
    except Exception as e:
      print(e)

BASE = "c:/temp/received/"

def receive_file(client_socket, addr):
  try :            
    data = client_socket.recv(1024)
    file_name, size = data.decode().split('/')
    size = int(size)

    client_socket.send("ready".encode())

    total_size = 0
    file_path = BASE + file_name
    with open(file_path, "wb") as f:
      while True:
        data = client_socket.recv(1024)
        f.write(data)
        total_size += len(data)
        if total_size >= size: break
              
      print(f"수신 완료: {file_name} / {total_size} bytes")
  except Exception as e:
    print(e)        
  finally:
    client_socket.close()
