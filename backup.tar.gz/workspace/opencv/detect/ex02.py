import cv2
from harrdetect import HarrDetect

cascade_file = "haarcascade_frontalface_alt.xml"
detecter = HarrDetect(cascade_file)

image_file = "../data/face2.jpg"		# ./data/face2.jpg
image = cv2.imread(image_file)

face_list = detecter.detect(image)
print(type(face_list))
if len(face_list):  # [] ==> False
  detecter.draw_rect(image, face_list)
  cv2.imwrite("facedetect-output2.PNG", image)
else:
  print("no face")