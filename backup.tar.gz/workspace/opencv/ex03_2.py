import cv2
from cam import Camera

cam = Camera(0)

cam.run()



