import cv2
from datetime import datetime

class Video:
  def __init__(self, src):
    self.cap = cv2.VideoCapture(2)		# 0번 카메라
    self.frame_size = (640, 480)
    self.fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    self.vwriter = None

  def start_record(self):
    if self.vwriter: return  # 이전에 r를 눌렀었는데, 또 r을 누른 경우
    start = datetime.now()
    fname = start.strftime('./data/%Y%m%d_%H%M%S.mp4') 
    self.vwriter = cv2.VideoWriter(fname, self.fourcc, 20.0, self.frame_size)
    print('start recording:', fname)

  def stop_record(self):
    if not self.vwriter: return

    self.vwriter.release()
    self.vwriter = None
    print('stop recording.')

  def run(self):
    while True:
      retval, frame = self.cap.read()	# 프레임 캡처
      if not retval: break

      if self.vwriter: self.vwriter.write(frame)
      cv2.imshow('frame', frame)

      key = cv2.waitKey(50)
      if key == ord('r'):
        self.start_record()
      elif key == ord('s'):
        self.stop_record()
      elif key == 27: # ESC
        break		

    self.cap.release()

    cv2.destroyAllWindows()



