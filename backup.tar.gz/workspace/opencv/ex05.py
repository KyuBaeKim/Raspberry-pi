import cv2
from datetime import datetime
import requests

cap = cv2.VideoCapture(2)		# 0번 카메라
frame_size = (640, 480)
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
file_name = ''
vwriter = None

def start_record():
  global vwriter, file_name
  if vwriter: return  # 이전에 r를 눌렀었는데, 또 r을 누른 경우

  start = datetime.now()
  file_name = start.strftime('./data/%Y%m%d_%H%M%S.mp4') 
  vwriter = cv2.VideoWriter(file_name, fourcc, 20.0, frame_size)

  print('start recording:', file_name)

def stop_record():
  global vwriter, file_name
  if not vwriter: return

  vwriter.release()
  vwriter = None
  
  print('stop recording.')
  

while True:
    retval, frame = cap.read()	# 프레임 캡처
    if not retval: break

    if vwriter: 
      vwriter.write(frame)

    cv2.imshow('frame', frame)
    key = cv2.waitKey(50)

    if key == ord('r'):
      start_record()
    elif key == ord('s'):
      stop_record()

    # 센서연계 -- pir 센서
    # HIGH 변경시 --> start_record() 호출  --> 사용자 카톡 메시지 전송
    # LOW 변경시 --> stop_record() 호출

    elif key == 27: # ESC
      break		

cap.release()

cv2.destroyAllWindows()



