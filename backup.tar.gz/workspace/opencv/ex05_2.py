import cv2
from cam import Camera
from datetime import datetime

cam = Camera(0)

file_name = ''
vwriter = None

def start_record():
  global vwriter, file_name
  if vwriter: return  # 이전에 r를 눌렀었는데, 또 r을 누른 경우
  
  start = datetime.now()
  file_name = start.strftime('./data/%Y%m%d_%H%M%S.mp4') 
  fourcc = cv2.VideoWriter_fourcc(*'mp4v')
  frame_size = (640, 480)
  vwriter = cv2.VideoWriter(file_name, fourcc, 20.0, frame_size)

  print('start recording:', file_name)

def stop_record():
  global vwriter, file_name
  if not vwriter: return

  vwriter.release()
  vwriter = None
  file_name = ''  
  print('stop recording.')
  

def callback(frame, key):
  if key == ord('r'):
    start_record()
  elif key == ord('s'):
    stop_record()
  
  if vwriter:
    vwriter.write(frame)
    
  return True

cam.callback = callback
cam.run()

