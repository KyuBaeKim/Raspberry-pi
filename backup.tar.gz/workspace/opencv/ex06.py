# 카메라 영상에서 얼굴을 찾아
# 사각형으로 표시하세요.

from cam import Camera
from harrdetect import HarrDetect

# cascade_file = "haarcascade_frontalface_alt.xml"
cascade_file = "haarcascade_fullbody.xml"

detecter = HarrDetect(cascade_file)
cap = Camera("./data/vtest.avi")

def callback(frame, _):
  object_list = detecter.detect(frame)
  if len(object_list) > 0 :
    detecter.draw_rect(frame, object_list, minSize = (50,50))
  return True

cap.callback = callback
cap.run()
