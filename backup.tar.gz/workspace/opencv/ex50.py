import cv2
from cam import Camera
import requests
from io import BytesIO
cam = Camera(0)

url = 'http://172.30.1.127:8000/api/stream_image/'

def callback(frame, key):
  encode_param=[int(cv2.IMWRITE_JPEG_QUALITY), 80]
  is_success, jpg = cv2.imencode(".jpg", frame, encode_param)
  
  res = requests.post(url, data=jpg.tobytes())

  return True

cam.callback = callback
cam.run(1)
