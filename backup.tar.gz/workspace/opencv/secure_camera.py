import cv2
from cam import Camera, VideoRecorder
from gpiozero import MotionSensor

recorder = VideoRecorder()

def callback(frame):

  return True


cam = Camera(0)
cam.callback = callback
cam.run()

