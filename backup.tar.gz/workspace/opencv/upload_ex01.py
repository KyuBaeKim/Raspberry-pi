import requests


# data = {
#   'file_name': '20220314_171053.mp4'
# }

# files = {
#   'video' : open('./data/20220314_171053.mp4', 'rb')
# }

# res = requests.post(url, data=data, files=files )
# print(res.status_code)
# print(res.json())


def upload(url, file_path):
  data = {
    'file_name': file_path.split('/')[-1]
  }

  files = {
    'video' : open(file_path, 'rb')
  }

  res = requests.post(url, data=data, files=files )
  if res.status_code == 200:
    result = res.json()
    if result.get('result') == 'suucess':
      return True

  return False


url = 'http://172.30.1.127:8000/api/upload_record/'
file_path = './data/20220314_171053.mp4' 
result = upload(url,file_path)
if result:
  print('upload success')
else:
  print('upload fail')


