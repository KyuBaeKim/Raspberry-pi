from threading import Thread
import requests, time
 
class HtmlGetter (Thread):
  def __init__(self, url):
    # super().__init__()    # 부모 생성자 호출
    Thread.__init__(self)   # super()를 사용하지 않는 경우 직접 self 전달 
    self.daemon = True
    self.url = url

  def run(self):
    resp = requests.get(self.url)
    time.sleep(1)
    print(self.url, len(resp.text), resp.text)
 
t = HtmlGetter('https://google.com')
t.start()
# t.run()
 
print("### End ###")
