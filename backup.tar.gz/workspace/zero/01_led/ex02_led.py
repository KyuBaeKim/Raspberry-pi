from gpiozero import LED
from signal import pause

red = LED(20)

red.blink(on_time=0.5, off_time=0.5) # 스레드로 동작하고 있다!!!

print('------------------')

pause()

# while True:   # busy waiting
#   pass
