from gpiozero import PWMLED
from signal import pause

led = PWMLED(20)

led.pulse()

pause()
