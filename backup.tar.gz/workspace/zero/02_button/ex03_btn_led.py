from gpiozero import Button, LED
from signal import pause


led = LED(20)
button = Button(16, bounce_time=0.02) 

# button.when_pressed = led.on
# button.when_released = led.off


led.source=button

pause()